<?php
class Mail extends AppModel {
	var $name = 'Mail';
	var $primaryKey = 'Id';
}
