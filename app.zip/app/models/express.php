<?php
class Express extends AppModel {
	var $name = 'Express';
	var $primaryKey = 'ExpressId';
	var $validate = array(
		'ExpressId' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
