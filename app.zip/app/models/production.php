<?php
class Production extends AppModel {
	var $name = 'Production';
	var $primaryKey = 'Id';
	var $displayField = 'CategoryId';
	var $validate = array(
		'Id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
