<?php
class MailsController extends AppController {

	var $name = 'Mails';
	function index($id) {
		$this->mail->recursive = 0;
		$this->set('mails', $this->Mail->find('all',array('condition'=>array('contacters'=>'='+$id))));
	}
	
}
